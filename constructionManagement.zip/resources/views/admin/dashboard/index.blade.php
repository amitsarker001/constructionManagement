<?php
/**
 * Created By: Amit Sarker
 * Created Date: 12-09-2020
 */
?>
@extends('admin.layouts.admin')
@section('content')
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Welcome</li>
    </ol>
@endsection



