<?php
/**
 * Created By: Amit Sarker
 * Created Date: 20-08-2020
 */
?>

<!-- Footer start -->
<div class="container-fluid">
    <div class="d-flex align-items-center justify-content-between small float-right">
        <div class="text-muted">Copyright &copy; {{getCompanyName()}} {{getCurrentYear()}}</div>
        <div class="d-none">
            <a href="#">Privacy Policy</a>
            &middot;
            <a href="#">Terms &amp; Conditions</a>
        </div>
    </div>
</div>
