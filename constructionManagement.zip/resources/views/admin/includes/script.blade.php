<?php
/**
 * Created By: Amit Sarker
 * Created Date: 12-09-2020
 */
?>
<script src="{{asset('assets/admin/js/scripts.js')}}"></script>

<script type="text/javascript" src="{{asset('assets/plugins/jquery-validation/dist/jquery.validate.min.js')}}"></script>
<script type="text/javascript"
        src="{{asset('assets/plugins/jquery-validation/dist/additional-methods.min.js')}}"></script>
<!-- Include SmartWizard CSS -->
<link href="{{asset('assets/plugins/SmartWizard-master/dist/css/smart_wizard.css')}}" rel="stylesheet"
      type="text/css"/>
<!-- Optional SmartWizard theme -->
<link href="{{asset('assets/plugins/SmartWizard-master/dist/css/smart_wizard_theme_arrows.css')}}"
      rel="stylesheet" type="text/css"/>
<!-- Include SmartWizard JavaScript source -->
<script type="text/javascript"
        src="{{asset('assets/plugins/SmartWizard-master/dist/js/jquery.smartWizard.js')}}"></script>
<!-- Custom Script -->
<script type="text/javascript" src="{{asset('assets/js/custom.js')}}"></script>

